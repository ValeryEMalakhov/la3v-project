CREATE TRIGGER add_filecache
BEFORE INSERT ON oc_filecache
FOR EACH ROW EXECUTE PROCEDURE add_filecache_func()