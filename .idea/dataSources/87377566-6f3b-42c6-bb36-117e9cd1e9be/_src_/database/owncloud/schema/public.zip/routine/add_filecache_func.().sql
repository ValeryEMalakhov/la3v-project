CREATE FUNCTION add_filecache_func () RETURNS trigger
	LANGUAGE plpgsql
AS $$
DECLARE
	testId int;
    testName varchar;

BEGIN

	testID = NEW.fileid;
    testName = NEW.name;
    
    IF(testName like '%.doc' 
        or testName like '%.docx'
        or testName like '%.pdf'
        or testName like '%.xls')
    THEN
    	INSERT INTO "document"."document" (doc_id, doc_title) VALUES
        	(testID, testName);
    END IF;

RETURN NEW;
END;
$$
