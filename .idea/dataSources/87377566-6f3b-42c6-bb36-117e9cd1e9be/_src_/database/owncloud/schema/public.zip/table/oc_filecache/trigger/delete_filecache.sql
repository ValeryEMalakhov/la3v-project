CREATE TRIGGER delete_filecache
BEFORE DELETE ON oc_filecache
FOR EACH ROW EXECUTE PROCEDURE delete_filecache_func()