CREATE FUNCTION delete_filecache_func () RETURNS trigger
	LANGUAGE plpgsql
AS $$

DECLARE
	testId int;
	testName varchar;

BEGIN

	testID = OLD.fileid;
	testName = OLD.name;

--    RAISE NOTICE 'Get ID (%)', testID;
--    RAISE NOTICE 'Get title (%)', testName;
    
    IF(testName like '%.doc%' 
        or testName like '%.docx%'
        or testName like '%.pdf%'
        or testName like '%.xls%')
    THEN
		DELETE FROM "document"."document" WHERE doc_id = testID;
		DELETE FROM "document"."doc_author" WHERE doc_id = testID;
		DELETE FROM "document"."doc_proc" WHERE doc_id = testID;
    END IF;

RETURN OLD;
END;
$$
